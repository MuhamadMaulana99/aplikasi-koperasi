<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Selamat Datang Di Dashboard</h1>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Commodi quasi cumque corporis minus nihil dolorem porro blanditiis velit, dolor et quod eligendi officiis nulla totam alias unde illum repellendus omnis?</p>
    <br><br>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi enim iste magnam unde tempora quae ipsum quod, esse illum quis, facere dolores cum fugiat. Sunt dolorum id vel voluptatibus temporibus.</p>
    <a href="../login/login.php">Login</a>
    
</body>
</html>