<?php
// untuk menghancurkan session agar user bisa login dan tidak error

session_start();
$_SESSION = [];
session_unset();
session_destroy();

// hancurkan cookie agar bisa logout
setcookie('id', '', time() - 3600);
setcookie('key', '', time() - 3600);

header("Location: ../login/login.php");
exit;
?>