<?php

session_start();
require '../config/functions.php';
//cek cookie
if(isset($_COOKIE['id']) && isset($_COOKIE['key']) ){
    $id = $_COOKIE['id'];
    $key = $_COOKIE['key'];

    // ambil user name berdasarkan id
    $result = mysqli_query($conn, "SELECT username FROM user WHERE id = $id");
    $row = mysqli_fetch_assoc($result);
    //cek cookie dan username
    if($key === hash('sha256', $row['username']) ){
        $_SESSION['login'] = true;
    }
    // cek ada ada sessionnya, maka kembalikan user ke halaman login(sebaliknya)
if (isset($_SESSION["login"])){
    header("Location: ../tabungan/index.php");
    exit;
}
}

//cek apakah tombol login sudah di pencet
    if ( isset($_POST["login"])){

        $username = $_POST["username"];
        $password = $_POST["password"];

        $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");
        //cek username
        if (mysqli_num_rows($result) === 1){
            //cek password
            $row = mysqli_fetch_assoc($result);
            // bandingkan password yang ada di user dan di database
            if (password_verify($password, $row["password"])){

            // set session
                $_SESSION["login"] = true;

            // cek remember me
            if( isset($_POST['remember'] ) ){
                // buat cookie
                setcookie('id', $row['id'], time()+ 60);
                setcookie('key', hash('sha256', $row['username']),time() + 60);
            }
                header("Location: ../tabungan/index.php");
                exit;
            }
        }
        $error = true;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css">
    <title>Halaman Login</title>
</head>
<body>
    <form action="" method="post">
        <h1 class=" offset-xl-8 my-5 color-primary">Koperasi Al-bayan</h1>
        <section class="vh-100">
            <div class="container-fluid h-custom">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-md-9 col-lg-6 col-xl-5">
        <img src="https://mdbootstrap.com/img/Photos/new-templates/bootstrap-login-form/draw2.png" class="img-fluid"
          alt="Sample image">
      </div>
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
      <?php if( isset($error)) :?>
        <p style="color: red; font-style: italic">Username / Password Salah!!</p>
    <?php endif;?>
        <form>
          <!-- Email input -->
          <div class="form-outline mb-4">
            <input type="text" name="username"  type="email" id="username" class="form-control form-control-lg"
              placeholder="Masukan Username" />
            <label class="form-label" for="username">Username</label>
          </div>
          <!-- Password input -->
          <div class="form-outline mb-3">
            <input name="password" type="password" id="password" class="form-control form-control-lg"
              placeholder="Masukan Password" />
            <label class="form-label" for="password">Password</label>
          </div>
          <div class="d-flex justify-content-between align-items-center">
            <!-- Checkbox -->
            <div class="form-check mb-0">
              <input class="form-check-input me-2" name="remember" type="checkbox" value="" id="remember" />
              <label class="form-check-label" for="remember">
                Remember me
              </label>
            </div>
            <a href="#!" class="text-body">Forgot password?</a>
          </div>
          <div class="text-center text-lg-start mt-4 pt-2">
            <button type="submit" name="login" class="btn btn-primary btn-lg"
              style="padding-left: 2.5rem; padding-right: 2.5rem;">Login</button>
              <p class="small fw-bold mt-2 pt-1 mb-0">Buat Akun? <a href="registrasi.php"
                  class="link-danger">Register</a></p>
                  <p class="small fw-bold mt-2 pt-1 mb-0">Masuk Sebagai Admin? <a href="../admin/index.php"
                  class="link-danger">Login Admin</a></p>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>
</section>
<!-- footer -->
<div class="container my-5">

  <footer class="text-center text-white">
</footer>
</div>
</form>
<div class="text-center text-dark p-3 col bg-primary">
  © 2021 Copyright:
  <a class="text-dark" href="https://www.instagram.com/muhamad_maulana00/">Muhamad Maulana</a>
</div>
<script src="../bootstrap-5.1.3-dist/js/bootstrap.bundle.js"></script>
</body>
</html>