<?php
require '../config/functions.php';
    // ketika tombol register maka jalankan di bawah ini
    if ( isset($_POST["register"]) ) {

        if( registrasi ($_POST) > 0 ){
            echo "<script>
                    alert('user baru di tambahkan!');
                    </script>";
        } else {
            echo mysqli_error($conn);
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Registrasi</title>
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css">
</head>
<body>
        <h1 class=" offset-xl-8 my-5 color-primary">Registrasi</h1>
        <section class="vh-100">
            <div class="container-fluid h-custom">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-md-9 col-lg-6 col-xl-5">
                        <img src="https://mdbootstrap.com/img/Photos/new-templates/bootstrap-login-form/draw2.png" class="img-fluid"
                                    alt="Sample image">
                    </div>
                        <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                        <form action="" method="post">
                            <!-- Email input -->
                        <div class="form-outline mb-4">
                            <input type="text" name="username"  type="text" id="username" class="form-control form-control-lg"
                            placeholder="Masukan Username" />
                            <label class="form-label" for="username">Username</label>
                        </div>
                                <!-- Password input -->
                        <div class="form-outline mb-3">
                            <input name="password" type="password" id="password" class="form-control form-control-lg"
                             placeholder="Masukan Password" />
                            <label class="form-label" for="password">Password</label>
                        </div>
                        <div class="form-outline mb-3">
                            <input name="password2" type="password" id="password2" class="form-control form-control-lg"
                            placeholder="Konfirmasi Password" />
                            <label class="form-label" for="password2">Konfirmasi Password</label>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                        <div class="text-center text-lg-start mt-4 pt-2">
                            <button type="submit" name="register" class="btn btn-primary btn-lg"
                            style="padding-left: 2.5rem; padding-right: 2.5rem;">Registrasi</button>
                        </form>
                            <p class="small fw-bold mt-2 pt-1 mb-0">Sudah Punya Akun? <a href="login.php"
                            class="link-danger">Login</a></p>
                    </div>
                 </div>
            </div>
        </section>
    </div>
    

    
        
        
    <!-- <form action="" method="post">
        <ul>
            <li>
                <label for="username">username : </label>
                <input type="text" name="username" id="username">
            </li>
            <li>
                <label for="password">password : </label>
                <input type="password" name="password" id="password">
            </li>
            <li>
                <label for="password2">konfirmasi password : </label>
                <input type="password" name="password2" id="password2">
            </li>
            <li>
                <button type="submit" name="register">Daftar</button>
            </li>
        </ul>
    </form> -->
    
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.bundle.js"></script>
</body>
</html>