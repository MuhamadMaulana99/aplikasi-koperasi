-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Des 2021 pada 01.57
-- Versi server: 10.4.19-MariaDB
-- Versi PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectkp`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `setoran`
--

CREATE TABLE `setoran` (
  `id` int(11) NOT NULL,
  `nama` varchar(15) NOT NULL,
  `norek` int(15) NOT NULL,
  `setoran` int(10) NOT NULL,
  `tandatangan` varchar(10) NOT NULL,
  `validasi` varchar(10) NOT NULL,
  `posting` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `setoran`
--

INSERT INTO `setoran` (`id`, `nama`, `norek`, `setoran`, `tandatangan`, `validasi`, `posting`) VALUES
(1, 'Muhamad Maulana', 123456789, 9000, '.', '.', '.'),
(10, 'Devti Mantan', 12346, 1000, '.', '.', '.'),
(11, 'Nur Amanah', 987644, 1000, '.', '.', '.'),
(16, 'maulana ganteng', 121313, 10000, 'okk', 'okk', 'okk'),
(17, 'Muhamad maulana', 4, 5324, 'gdsf', 'dfgs', 'dfgd'),
(18, 'intan', 23242, 234123, 'sfa', 'dsfg', 'dfga'),
(19, 'maul ganteng', 4, 80000, 'oke', 'oke juga', 'oke banget'),
(20, 'aku', 23242, 2342, 'wdaws', 'dfga', 'dfgsd');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(11) NOT NULL,
  `password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_tabungan`
--

CREATE TABLE `tb_tabungan` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `noakad` int(40) NOT NULL,
  `setoran` int(11) NOT NULL,
  `tandatangan` varchar(15) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `posting` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_tabungan`
--

INSERT INTO `tb_tabungan` (`id`, `nama`, `noakad`, `setoran`, `tandatangan`, `validasi`, `posting`) VALUES
(1, 'Aril', 234234, 3456356, 'okk', 'okk', 'okk'),
(3, 'maulana', 5235, 54613, 'oke', 'fghf', 'ghs'),
(4, 'Ariel', 563, 456345, 'dfghs', 'dgh', 'dfghs'),
(5, 'tyas', 1010011, 1000, 'ok', 'ok', 'ok'),
(6, 'baru', 10101, 100000, 'ok', 'ok', 'okkkkkk'),
(7, 'bagas', 3453, 345453, 'fgdf', 'dfgdf', 'dfgsd'),
(9, 'gfgfh', 56745, 567456, 'fghdfg', 'gfhdf', 'fghdf');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'maul', '$2y$10$xNNd5QMnuFDnjh9F9kJIjeuGxGLTXky77bMcd1Hv30L2kkXPWAJkS'),
(2, 'maulana', '$2y$10$dvtCXFHN17pgq/3ew5JkVertE3n0QtqdXfAUDd5bZKExfTubpfHkW'),
(7, 'alan', '$2y$10$OWh2qu5zK6mRNOmO2Gk35uxYCtjIiI0rWVdOR28xWfurQf4t9jBUK'),
(8, 'zayadi', '$2y$10$rC1UoDVKO4zGotEjg7zg7.DELZeIMfcqF/iOmzkkmDb8Z2C1o/AOi');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `setoran`
--
ALTER TABLE `setoran`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_tabungan`
--
ALTER TABLE `tb_tabungan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `setoran`
--
ALTER TABLE `setoran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_tabungan`
--
ALTER TABLE `tb_tabungan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
