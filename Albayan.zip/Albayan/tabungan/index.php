<?php

session_start();
// cek session
if (!isset($_SESSION["login"])){
    header("Location: ../login/login.php");
    exit;
}

require 'functions.php';
 //pagination (LIMIT indexnya 0) tampilkan 2 data dari index ke1
 //konfigurasi
 $jumlahDataPerhalaman = 5;
 $jumlahData = count(query("SELECT * FROM tb_tabungan"));
 $jumlaHalaman = ceil($jumlahData / $jumlahDataPerhalaman);
 $halamanAktif = ( isset($_GET["halaman"]) ) ? $_GET["halaman"] : 1;
 
 $awalData = ($jumlahDataPerhalaman * $halamanAktif) - $jumlahDataPerhalaman;
 $setoran = query("SELECT * FROM tb_tabungan LIMIT $awalData, $jumlahDataPerhalaman ");
 
 // jika tombol di klik
 if ( isset($_POST["cari"]) ){
     $setoran = cari($_POST["keyword"]);
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Tabungan</title>
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css">
    <style>
        img{
            width: 100px;
            height: 100px;
        }
        /* print pdf memlalui css, pada saat di print logout tidak ada */
        @media print{
            .logout, .tambah, .form-cari, .aksi {
                display: none;
            }
        }
    </style>
</head>
<body>
<div class="bg-warning">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary affix">
        <div class="container-fluid">
          <a class="navbar-brand" href="">Menu</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="../dashboard/index.php">Dashboard</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Data Tabungan
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="index.php">Tabungan</a></li>
                  <li><a class="dropdown-item" href="../angsuran/index.php">Angsuran</a></li>
                  <li><a class="dropdown-item" href="#">Administrasi</a></li>
                  <li><a class="dropdown-item" href="#">Penarikan</a></li>
                  <li><a class="dropdown-item" href="#">Realisasi Pembiayaan</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="#">Beranda</a></li>
                  <a class="dropdown-item" href="../logout/logout.php">Logout</a></li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link active">Koperasi AL-Bayan</a>
              </li>
            </ul>
            <form class="d-flex">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-warning " type="submit">Search</button>
            </form>
          </div>
        </div>
      </nav>

      <div class="container-fluid">
<h1>Daftar Nasabah</h1>

<a href="tambah.php" class="btn btn-primary">Tambah Data</a>
<br><br>
<form action="" method="post" class="form">
  <div class="form-group">
    <div class="col-xs-6">
         <input class="form-control" type="text" name="keyword" placeholder="Cari Data setoran" autocomplete="off">
         <button type="submit" name="cari" class="btn btn-primary my-2">Cari!</button>
  </div>
  </div>
</form>

<div class="mx-2">
        <!-- navigasi pagination -->
<?php if( $halamanAktif > 1 ) : ?>
    <a href="?halaman=<?= $halamanAktif - 1 ?>">&lt;</a>
<?php endif; ?>

    <?php for($i = 1; $i <= $jumlaHalaman; $i++ ) :?>
        <?php if( $i == $halamanAktif) : ?>
        <a href="?halaman=<?= $i; ?>" style="font-weight: bold; color: red;"><?= $i; ?></a>
        <?php else :?>
            <a href="?halaman=<?= $i; ?>"><?= $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>
    
<?php if( $halamanAktif < $jumlaHalaman ) : ?>
    <a href="?halaman=<?= $halamanAktif + 1 ?>">&gt;</a>
<?php endif; ?>
</div>
  <table border="1" cellpadding="10" cellspacing="0" class="px-4 table table-dark table-striped">
      <tr>
          <th>No.</th>
          <th class="crud">CRUD</th>
          <th>Nama</th>
          <th>No Akad</th>
          <th>Setoran</th>
          <th>Tanda Tangan</th>
          <th>Validasi</th>
          <th>Posting</th>
      </tr>
          <?php $i = 1; ?>
          <?php foreach($setoran as $row) : ?>
      <tr>
          <td><?= $i; ?></td>
          <td class="crud">
              <a  class="btn btn-outline-primary" href="ubah.php?id=<?= $row["id"]; ?>">Ubah</a> |
              <a  class="btn btn-outline-danger" href="hapus.php?id=<?= $row["id"]; ?>" onclick="return confirm('Anda Yakin Ingin Menghapus??'); ">Hapus</a>
          </td>
          <td><?= $row["nama"]; ?></td>
          <td><?= $row["noakad"]; ?></td>
          <td><?= $row["setoran"]; ?></td>
          <td><?= $row["tandatangan"]; ?></td>
          <td><?= $row["validasi"]; ?></td>
          <td><?= $row["posting"]; ?></td>
      </tr>
      <?php $i++; ?>
      <?php endforeach; ?>

    </table>
    <a href="tambah.php" class="btn btn-primary my-2 float-end">Kirim</a>
  </div>
  <footer class="">
    <div class="text-center text-dark p-3 col bg-primary">
      © 2021 Copyright:
      <a class="text-dark" href="https://www.instagram.com/muhamad_maulana00/">Muhamad Maulana</a>
    </div>
  </footer>
</div> 

<script src="../bootstrap-5.1.3-dist/js/bootstrap.bundle.js"></script>
</body>
</html>

