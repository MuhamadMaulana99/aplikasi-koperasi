<?php
session_start();
// cek ada gak sessionnya, maka kembalikan user ke halaman login
if (!isset($_SESSION["login"])){
    header("Location: ../login/login.php");
    exit;
}
require 'functions.php';
//cek apakah tombol submit sudah di pencet apa belum
    if( isset($_POST["submit"])){

        //cek apakah data berhasil di tambahkan atau tidak dan kembali ke halaman index
        if( tambah($_POST) > 0 ){
            echo "
            <script>
                alert('Data Berhasil Di Tambahkan!');
                document.location.href = 'index.php'; 
            </script>
            ";
        } else {
            echo "
            <script>
                alert('Data Gagal Di Tambahkan!');
                document.location.href = 'index.php'; 
            </script>
            ";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Data Mahasiswa </title>
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary affix">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Menu</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="../dashboard/index.php">Dashboard</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Data Tabungan
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="index.php">Tabungan</a></li>
                  <li><a class="dropdown-item" href="../angsuran/index.php">Angsuran</a></li>
                  <li><a class="dropdown-item" href="#">Administrasi</a></li>
                  <li><a class="dropdown-item" href="#">Penarikan</a></li>
                  <li><a class="dropdown-item" href="#">Realisasi Pembiayaan</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="#">Beranda</a></li>
                  <a class="dropdown-item" href="../logout/logout.php">Logout</a></li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link active">Koperasi AL-Bayan</a>
              </li>
            </ul>
            <form class="d-flex">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-warning " type="submit">Search</button>
            </form>
          </div>
        </div>
      </nav>

<h1 class="">Ubah Data Tabungan</h1>
    <div class="container bg-primary border border-4 rounded-3 mb-6">
        <form class="mb-6" action="" method="post">
            <input type="hidden" name="id" >
            <div class="mb-3">
                <label for="nama" class="form-label">NAMA</label>
                <input class="form-control" type="text" name="nama" id="nama" >
            </div>
            <div class="mb-3">
                <label for="noakad" class="form-label">No Akad</label>
                <input class="form-control" type="text" name="noakad" id="norek" >
            </div>
            <div class="mb-3">
                <label for="noakad" class="form-label">Tabungan</label>
                <input class="form-control" type="text" name="setoran" id="setoran" >
            </div>
            <div class="mb-3">
                <label for="tandatangan" class="form-label">Tanda Tangan </label>
                <input class="form-control" type="text" name="tandatangan" id="tandatangan" >
            </div>
            <div class="mb-3">
                <label for="validasi" class="form-label">Validasi </label>
                <input class="form-control" type="text" name="validasi" id="validasi" >
            </div class="mb-3">
            <div class="mb-3">
                <label for="posting" class="form-label">Posting </label>
                <input class="form-control" type="text" name="posting" id="posting" >
            </div>
            <div class="mb-3">
                <label for="" class="form-label"> </label>
            </div>
            <button class="btn btn-outline-warning btn-lg" type="submit" name="submit">Tambah Data!</button>
            <div class="mb-2">
                <label for="" class="form-label"></label>
            </div>
        </form>
    </div>
    <footer class="fixed-bottom mt-5">
        <div class="text-center text-dark p-3 col bg-primary mt-5">
        © 2021 Copyright:
        <a class="text-dark" href="https://www.instagram.com/muhamad_maulana00/">Muhamad Maulana</a>
        </div>
    </footer>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.bundle.js"></script>
</body>
</html> 