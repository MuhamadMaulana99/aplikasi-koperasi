
<?php

$conn = mysqli_connect("localhost", "root", "", "projectkp");

function query($query){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
      while( $row = mysqli_fetch_assoc($result)){
          $rows[] = $row;
      }
      return $rows;
}

// fngsi tambah

function tambah($data){
    // htmlspecialchars(untuk tidak di hack)
    global $conn;
    $nama = htmlspecialchars( $data["nama"]);
    $noakad  = htmlspecialchars($data["noakad"]);
    $setoran = htmlspecialchars($data["setoran"]);
    $tandatangan = htmlspecialchars($data["tandatangan"]);
    $validasi = htmlspecialchars($data["validasi"]);
    $posting = htmlspecialchars($data["posting"]);
    
    //query insert data
    $query = "INSERT INTO tb_tabungan 
    VALUES('', '$nama', '$noakad', '$setoran', '$tandatangan', '$validasi','$posting')";
    mysqli_query($conn, $query );
    return mysqli_affected_rows($conn);
}

//fungsi hapus

 function hapus($id){
     global $conn;
     mysqli_query($conn, "DELETE FROM tb_tabungan WHERE id = $id");
     return mysqli_affected_rows($conn);
 }

 //fungsi ubah

function ubah($data){
    // htmlspecialchars(untuk tidak di hack)
    global $conn;
    $id = $data["id"];
    $nama = htmlspecialchars( $data["nama"]);
    $noakad  = htmlspecialchars($data["noakad"]);
    $setoran = htmlspecialchars($data["setoran"]);
    $tandatangan = htmlspecialchars($data["tandatangan"]);
    $validasi = htmlspecialchars($data["validasi"]);
    $posting = htmlspecialchars($data["posting"]);

    //query update data
    $query = "UPDATE tb_tabungan SET 
                nama = '$nama',
                noakad = '$noakad',
                setoran = '$setoran',
                tandatangan = '$tandatangan',
                validasi = '$validasi',
                posting = '$posting'
                WHERE id = $id
                ";
    mysqli_query($conn, $query );

    return mysqli_affected_rows($conn);
}

//fungsi  pencarian
function cari($keyword){
    $query = "SELECT * FROM tb_tabungan 
                WHERE 
                nama LIKE '%$keyword%'
                ";
    return query($query);
}

//fungsi registrasi
// function registrasi($data){
//     global $conn;

//     $username = strtolower(stripslashes ($data["username"]));
//     $password = mysqli_real_escape_string($conn, $data["password"]);
//     $password2 = mysqli_real_escape_string($conn, $data["password2"]);

//     //cek username sudah ada atau belum
//     $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
//     if(mysqli_fetch_assoc($result)){
//         echo "<script>
//         alert('username yang anda masukan sudah terdaftar!');
//         </script>";
//         return false;
//     }
    

//     //cek konfirmasi password
//     if ( $password !== $password2 ){
//         echo "<script>
//         alert('konfirmasi password tidak sesuai');
//         </script>";
//         return false;
//     }
//     // enkripsi password / mengamankan pasword
//     $password = password_hash($password, PASSWORD_DEFAULT);
//     //tambahkan user baru ke database
//     mysqli_query($conn, "INSERT INTO user VALUES('', '$username', '$password')");

//     return mysqli_affected_rows($conn);
// }


?>

