<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary affix">
        <div class="container-fluid">
          <a class="navbar-brand" href="">Menu</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="../dashboard/index.php">Dashboard</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Data Tabungan
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="index.php">Tabungan</a></li>
                  <li><a class="dropdown-item" href="../angsuran/index.php">Angsuran</a></li>
                  <li><a class="dropdown-item" href="#">Administrasi</a></li>
                  <li><a class="dropdown-item" href="#">Penarikan</a></li>
                  <li><a class="dropdown-item" href="#">Realisasi Pembiayaan</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="#">Beranda</a></li>
                  <a class="dropdown-item" href="../logout/logout.php">Logout</a></li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link active">Koperasi AL-Bayan</a>
              </li>
            </ul>
            <form class="d-flex">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-warning " type="submit">Search</button>
            </form>
          </div>
        </div>
      </nav>

    <div class="container-fluid">
  <div class="row bg-primary">
    <div class="col bg-info">
      <h1>KBMT Al-Bayan Tabungan</h1>
      <br>
    <div class="input-group mb-3 my-2">
        <input type="text" class="form-control" placeholder="Tulis Tanggal" aria-label="Recipient's username" aria-describedby="button-addon2">
        <button class="btn btn-outline-primary" type="button" id="button-addon2">Cari</button>
    </div>
    <div class="input-group mb-3 my-2">
        <input type="text" class="form-control" placeholder="Nama Nasabah" aria-label="Recipient's username" aria-describedby="button-addon2">
        <button class="btn btn-outline-primary" type="button" id="button-addon2">Cari</button>
    </div>
    <div class="input-group mb-3 my-2">
        <input type="text" class="form-control" placeholder="No. Rekening" aria-label="Recipient's username" aria-describedby="button-addon2">
        <button class="btn btn-outline-primary" type="button" id="button-addon2">Cari</button>
    </div>
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Kode" aria-label="Recipient's username" aria-describedby="button-addon2">
        <button class="btn btn-outline-primary" type="button" id="button-addon2">Cari</button>
    </div>
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Setoran" aria-label="Recipient's username" aria-describedby="button-addon2">
        <button class="btn btn-outline-primary" type="button" id="button-addon2">Cari</button>
    </div>
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Penarikan" aria-label="Recipient's username" aria-describedby="button-addon2">
        <button class="btn btn-outline-primary" type="button" id="button-addon2">Cari</button>
    </div>
    </div>
    <div class="col-6 bg-warning">
      <h1 class="text-align-center" >Table</h1>
    </div>

    <div class="col bg-info">
        <h3>Jenis Tampilan</h3>
        <div class="form-check ">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
            <label class="form-check-label" for="flexRadioDefault1">Tanggal</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
            <label class="form-check-label" for="flexRadioDefault2">Rekening</label>
        </div>
        <h3>Bagi Hasil</h3>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
            <label class="form-check-label" for="flexRadioDefault1">Tanggal</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
            <label class="form-check-label" for="flexRadioDefault2">Rekening</label>
        </div>
        <h3>Saldo</h3>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
            <label class="form-check-label" for="flexRadioDefault1">Tanggal</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
            <label class="form-check-label" for="flexRadioDefault2">Rekening</label>
        </div>
    </div>
  </div>
</div>
<script src="../bootstrap-5.1.3-dist/js/bootstrap.bundle.js"></script>
</body>
</html>