<?php
session_start();
// cek ada gak sessionnya, maka kembalikan user ke halaman login
if (!isset($_SESSION["login"])){
    header("Location: ../login/login.php");
    exit;
}
require '../config/functions.php';
$id = $_GET["id"];

if ( hapus($id) > 0){
    echo "
            <script>
                alert('Data Anda Telat Terhapus!!');
                document.location.href = 'index.php'; 
            </script>
            ";
} else{
    echo "
            <script>
                alert('Data GAGAL Di Hapus!');
                document.location.href = 'index.php'; 
            </script>
            ";
}

?>